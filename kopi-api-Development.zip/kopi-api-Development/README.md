# kopi-api
Rest Api for coffee using laravel framework with repository pattern

# Libraries

The libraries and tools used include:
* [Laravel Passport](https://laravel.com/docs/master/passport)
* [Fractal](http://fractal.thephpleague.com/transformers/)
* [JwtAuth](https://github.com/tymondesigns/jwt-auth)
* [Guzzle](https://github.com/guzzle/guzzle)
* [Carbon](http://carbon.nesbot.com/docs/)
